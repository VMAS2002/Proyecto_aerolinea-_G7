package Aerolinea.Dao;


import Aerolinea.Domain.Tripulacion;
import java.util.List;
import org.springframework.data.repository.CrudRepository;

public interface TripulacionDao extends CrudRepository<Tripulacion,Long> {


    }
