
package Aerolinea.Dao;


import Aerolinea.Domain.Paises;
import org.springframework.data.repository.CrudRepository;

public interface PaisesDao extends CrudRepository<Paises, Long> {
    
}
